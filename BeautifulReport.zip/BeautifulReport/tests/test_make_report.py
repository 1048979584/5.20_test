import os
import unittest
from selenium import webdriver
from lxml import etree
from BeautifulReport import BeautifulReport
class UiAutoTestCase(unittest.TestCase):
    """ 测试报告的基础用例Sample """
    driver = None
    img_path = 'img'

    def save_img(self, img_name):
        """
            传入一个img_name, 并存储到默认的文件路径下
        :param img_name:
        :return:
        """
        self.driver.get_screenshot_as_file('{}/{}.png'.format(os.path.abspath(self.img_path), img_name))

    @classmethod
    def setUpClass(cls):
        """ set Up method """
        cls.driver = webdriver.Chrome()
        cls.test_page = 'https://www.baidu.com/'
    
    def tearDown(self):
        """ tear Down method """
    
    @classmethod
    def tearDownClass(cls):
        """ tear Down method """
        cls.driver.close()

    def test_home_page_is_ok(self):
        """
        测试访问首页正常, 并使用title进行断言
        """
        self.driver.get(self.test_page)
        print('打开浏览器, 访问: {}'.format(self.test_page))
        title = self.driver.title
        print(title)
        print('获取到对应的title: {}'.format(title))
        self.assertEqual(title, "百度一下，你就知道")

    @BeautifulReport.add_test_img('点击第一个文章页面前', '点击第一个文章页面后')
    def test_save_img_and_view(self):
        """
            打开首页, 截图, 在截图后点击第一篇文章连接, 跳转页面完成后再次截图
        """
        self.driver.get(self.test_page)
        self.save_img('点击第一个文章页面前')
        self.driver.find_element_by_link_text('新闻').click()
        self.save_img('点击第一个文章页面后')
        print('跳转与保存截图完成')
        self.assertEqual(
            self.driver.find_element_by_xpath('//*[@id="pane-news"]/div/ul/li[1]/strong/a').text,
            '习近平告诉你，我们的制度为何深得人民拥护'
        )

    @BeautifulReport.add_test_img('test_errors_save_imgs')
    def test_errors_save_imgs(self):
        """
            如果在测试过程中, 出现不确定的错误, 程序会自动截图, 并返回失败, 如果你需要程序自动截图, 则需要咋测试类中定义 save_img方法
        """
        self.driver.get(self.test_page)
        self.driver.find_element_by_xpath('//abc')

    @BeautifulReport.add_test_img('test_success_case_img')
    def test_success_case_img(self):
        """
            如果case没有出现错误, 即使使用了错误截图装饰器, 也不会影响case的使用
        """
        self.driver.get(self.test_page)
        self.driver.find_element_by_xpath('//title/text()')
